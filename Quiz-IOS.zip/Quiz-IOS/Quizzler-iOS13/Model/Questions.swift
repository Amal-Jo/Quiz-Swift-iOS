//
//  Questions.swift
//  Quizzler-iOS13
//
//  Created by Amal Joseph on 2020-08-08.
//  Copyright © 2020 The App Brewery. All rights reserved.
//

import Foundation
struct Questions {
    let text:String
    let answer:String
    
    init(q:String,a:String) {
        text=q
        answer=a
    }
}
